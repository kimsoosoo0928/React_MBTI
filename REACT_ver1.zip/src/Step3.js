import React, { useState } from 'react';
import {Route,Link} from 'react-router-dom'

export default function Step3 ({match}) {    
    return (
        <div>
        
    <h2>당신과 최고의 궁합 관상!</h2>
    <h3>당신과 최고의 궁합 유형은 XXXX입니다!</h3>
    <img src="C:\Users\kimhs\Desktop\REACT\src\m.jpg" width="128" height="128"/>
    <p>(최고의 궁합 관상)</p>
    <p>XXXX는 !@#%$ .....</p>
    <p><button type="submit">Submit</button></p>
    

    </div>

    );
}


